<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php";

$catname=buildReverseURL($_REQUEST['cat_id']);
// echo "<br/>";
 $productname=buildReverseURL($_REQUEST['p_name']);

 $rowcatproduct=$objU->getResult('select * from manage_category where category_name like "%'.$catname.'%" order by id desc');
//die;

$productsingle=$objU->getResult('select * from tbl_product where name like "'.$productname.'%" and cat_id="'.$rowcatproduct[0]['id'].'"');
//print_r($productsingle);
?>
<section class="clearfix bearcrumb-back">
	<div class="container">
		<div class="row">
			<div class="beardcrumb">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="">Products</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-9">
				<div class="col-md-12 p-0">
					<?php include "include/shop-by-brand.php" ?>
				</div>
				<div class="col-md-12 p-0">
					<div class="col-md-6 product-single">
					<div class="product-img-wrap">
						<?php 
$productsingleimg=$objU->getResult('select * from tbl_pro_img where p_id="'.$productsingle[0]['id'].'"');

?>
						
						<!--<img src="TBXadmin/upload/product/big/<?php echo $productsingleimg[0]['image']; ?>" class="img-responsive" > -->
						<img src="images/product.jpg" class="img-responsive">
						</div>
					</div>
					<div class="col-md-6">
						<div class="product-descp">
							<h3><?php echo $productsingle[0]['name'] ?></h3>
							<p><?php echo $productsingle[0]['short_description'] ?> </p>
						</div>
						<!--
						<div class="select-medication">
							<div class="form-group">
								<label>*Select Medication</label>
								<select class="form-control">
									<option>--plese select--</option>
									<option>option1</option>
									<option>option2</option>
									<option>option3</option>
									<option>option4</option>
								</select>
							</div>
						</div> -->
					</div>
				</div>
                         <div class="col-md-12 p-0 compnay-list clearfix ">
                             <h3>select company</h3>
                         	<ul style="list-style: none;">
                             <?php

                              $productsinglecompany=$objU->getResult('select * from tbl_company where product_id="'.$productsingle[0]['id'].'"');

                              foreach($productsinglecompany as $keycompany => $valcompany) 
                              {
                               ?>
                               <li>
                         			<?php //echo $valcompany['company_name']; ?>

                         			<img src="TBXadmin/upload/company/<?php echo $valcompany['logo'] ?>"  height="100" width="100" onclick="callvarient(<?php echo $productsingle[0]['id'] ?>,<?php echo $valcompany['id'] ?>)">
                         		</li>
                         	<?php } ?>
                         	</ul>

                         </div>

				<div class="col-md-12 p-0 feature-product products-tab clearfix " id="resultpackage" style="display: none;">
					<div role="tabpanel" class="f-tab clearfix">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">

							  <?php 
							   $productsinglevarient=$objU->getResult('select * from product_varient where product_id="'.$productsingle[0]['id'].'"');

							   foreach($productsinglevarient as $varientkey => $varientval) {

							  ?>
							<li role="presentation" class="active">
								<a href="#varient<?php echo $varientval['id']; ?>" aria-controls="home" role="tab" data-toggle="tab"><?php echo $productsingle[0]['name'] ?> <?php echo $varientval['varient']; ?> <?php echo $varientval['varient_unit']; ?> </a>
							</li>
						<?php } ?>
							
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">

                         <?php  foreach($productsinglevarient as $varientkey => $varientval) { ?>

							<div role="tabpanel" class="tab-pane active" id="varient<?php echo $varientval['id']; ?>">
								<div class="col-md-12 p-0>">
									<div class="table-responsive">
										<table class="table">
											<tr>
												<th>Package</th>
												<th>Per Pills</th>
												<th>Price</th>
												<th>Savings</th>
												<th>Bonus</th>
												<th>order</th>
											</tr>


											<?php 
											$productsinglepackage=$objU->getResult('select * from tbl_product_package where product_id="'.$varientval['product_id'].'" and varient_id="'.$varientval['id'].'" and company_id=11');

											foreach($productsinglepackage as $keypackage => $valpackage)
											{
											?>
											<tr>
												<td><?php echo $varientval['varient']; ?> <?php echo $varientval['varient_unit']; ?> x <?php echo $valpackage['no_pills']; ?> pills</td>
												<td>$<?php echo $valpackage['per_pill_price']; ?> </td>
												<td>$<?php echo $valpackage['price']; ?></td>
												<td><?php echo $discountmout=number_format(($valpackage['price']*$valpackage['discount'])/100,2); ?></td>
												<td>+<?php echo $valpackage['bonus']; ?></td>
												<td><a href="javascript:void(0)" onclick="addcart(<?php echo $valpackage['id']; ?>)" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>

										<?php } ?>
										
											
										</table>
									</div>
								</div>
							</div>
                             <?php } ?>

							<div role="tabpanel" class="tab-pane" id="tab">
								cacacacac
							</div>
							<div role="tabpanel" class="tab-pane" id="tab1">
								bdbdbdb
							</div>
							<div role="tabpanel" class="tab-pane" id="tab2">
								sdgsdfgdfsg
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12 p-0 clearfix">
					<div class="p-accord-wrap">
						<div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="headingOne">
									<h4 class="panel-title">
										<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Product Description
										</a>
									</h4>
								</div>
								<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
									<div class="panel-body">
										<?php echo $productsingle[0]['product_description']; ?>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="headingTwo">
									<h4 class="panel-title">
										<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Sefty Information
										</a>
									</h4>
								</div>
								<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
									<div class="panel-body">
										<?php echo $productsingle[0]['safety_information']; ?>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="headingThree">
									<h4 class="panel-title">
										<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Side Effects
										</a>
									</h4>
								</div>
								<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
									<div class="panel-body">
											<?php echo $productsingle[0]['side_effects']; ?>
									</div>
								</div>
							</div>
						</div><!-- panel-group -->
					</div><!-- container -->
				</div>
				<div class="col-md-12 p-0 clearfix">
					<div class="sbb text-light-green">
						<h3>Related Products</h3>
					</div>
					<div class="col-md-12 p-0">
						<div class="col-md-3 p-0-7">
							<a href="products.php">		<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
								</div></a>
						</div>
						<div class="col-md-3 p-0-7">
							<a href="products.php">		<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
								</div></a>
						</div>
						<div class="col-md-3 p-0-7">
							<a href="products.php">		<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
								</div></a>
						</div>
						<div class="col-md-3 p-0-7">
							<a href="products.php">		<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
								</div></a>
						</div>
						<div class="col-md-3 p-0-7">
							<a href="products.php">		<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
								</div></a>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">text/javascript
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include "include/footer.php" ?>
<script type="text/javascript">


	function callvarient(pid,companyid)
       {
            
            $('#resultpackage').show();
            $('#resultpackage').html('<img src="images/loader.gif"');
			$.ajax({
				type: "post",
				url: "ajax/getpackages.php",
				data: {'companyid':companyid, 'pid': pid},
				 success: function(result){
				 	$('#resultpackage').html(result);
				 	//console.log(result);
				 	 // $('.cart-sb').css("right", "0px"); 
				 	//alert(result);
				 	//alert("Product added successfully in your cart");
		        // $("#div1").html(result);
		    }});
	}

	function addcart(packageid,qty){
      $('.addcart_'+packageid).hide();
      $('.cartloader_'+packageid).show();
       $.ajax({
				type: "post",
				url: "ajax/addtocart.php",
				data: {'packageid':packageid,'qty':qty},
				 success: function(result){
				 	getcartcount();
				 	$('.addcart_'+packageid).hide();
      $('.cartloader_'+packageid).hide();
      $('.removecart_'+packageid).show();
				 	//$('#resultpackage').html(result);
				 	//console.log(result);
				 	 // $('.cart-sb').css("right", "0px"); 
				 	//alert(result);
				 	//alert("Product added successfully in your cart");
		        // $("#div1").html(result);
		    }});

	}

	function removecart(packageid,pid,companyid){

              $.ajax({
				type: "post",
				url: "ajax/removecart.php",
				data: {'packageid':packageid},
				 success: function(result){
				 	callvarient(pid,companyid);
				 	getcartcount();
				 	
				 	//$('#resultpackage').html(result);
				 	//console.log(result);
				 	 // $('.cart-sb').css("right", "0px"); 
				 	//alert(result);
				 	//alert("Product added successfully in your cart");
		        // $("#div1").html(result);
		    }});

	        }


  
</script>
