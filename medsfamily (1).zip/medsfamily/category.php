<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php";
//print_r($_REQUEST);
$catname=buildReverseURL($_REQUEST['cat_id']);


 $rowcatproduct=$objU->getResult('select * from manage_category where category_name like "%'.$catname.'%" order by id desc');
?>
<section class="clearfix bearcrumb-back">
	<div class="container">
		<div class="row">
			<div class="beardcrumb">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="">Category</a></li>

				</ul>
			</div>
		</div>
	</div>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-9">
				<div class="col-md-12 p-0">
					<div class="category-banner">
						<img src="images/category-banner.jpg" class="img-responsive">
						<p>simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance.</p>
					</div>
				</div>
				<div class="col-md-12 p-0">
					<?php include "include/shop-by-brand.php" ?>
				</div>
				<div class="col-md-12 category-main p-0">

                <?php $productsinglecat=$objU->getResult('select * from tbl_product where cat_id="'.$rowcatproduct[0]['id'].'"'); 
                foreach($productsinglecat as $keyproduct => $valproduct)
                     {
                ?>
					<div class="col-md-3 p-0-7">
						<a href="product/<?php  echo buildURL($rowcatproduct[0]['category_name']); ?>/<?php  echo buildURL($valproduct['name']); ?>.htm"><div class="feature-wrap">
							<?php 
$productsingleimg=$objU->getResult('select * from tbl_pro_img where p_id="'.$valproduct['id'].'"');

?>
							<img src="TBXadmin/upload/product/big/<?php echo $productsingleimg[0]['image']; ?>" class="img-responsive">
							<div class="feature-cost text-center">
								<p><?php echo $valproduct['name'] ?></p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>

								<?php  
                                   
								$productsingleprice=$objU->getResult('select min(per_pill_price) as minprice from tbl_product_package where product_id="'.$valproduct['id'].'"');  ?>
								<h3><?php echo $_SESSION['currency_symbol']; ?><?php echo $productsingleprice[0]['minprice'] ?></h3>
								<a href="product/<?php  echo buildURL($rowcatproduct[0]['category_name']); ?>/<?php  echo buildURL($valproduct['name']); ?>.htm" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div></a>
					</div>
				<?php } ?>



				</div>
			</div>
		</div>
	</div>
</section>










<?php include "include/footer.php" ?>
