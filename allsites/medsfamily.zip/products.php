<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php"
?>
<section class="clearfix bearcrumb-back">
	<div class="container">
		<div class="row">
			<div class="beardcrumb">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="">Products</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-9">
				<div class="col-md-12 p-0">
					<?php include "include/shop-by-brand.php" ?>
				</div>
				<div class="col-md-12 p-0">
					<div class="col-md-6 product-single">
					<div class="product-img-wrap">
						<img src="images/product-img.png" class="img-responsive">
						</div>
					</div>
					<div class="col-md-6">
						<div class="product-descp">
							<h3>Acetran</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer . </p>
						</div>
						<div class="select-medication">
							<div class="form-group">
								<label>*Select Medication</label>
								<select class="form-control">
									<option>--plese select--</option>
									<option>option1</option>
									<option>option2</option>
									<option>option3</option>
									<option>option4</option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12 p-0 feature-product products-tab clearfix ">
					<div role="tabpanel" class="f-tab clearfix">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">
							<li role="presentation" class="active">
								<a href="#home" aria-controls="home" role="tab" data-toggle="tab">Acetram 30MCG</a>
							</li>
							<li role="presentation">
								<a href="#tab" aria-controls="tab" role="tab" data-toggle="tab">Acetram 30MCG</a>
							</li>
							<li role="presentation">
								<a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">Acetram 30MCG</a>
							</li>
							<li role="presentation">
								<a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Acetram 30MCG</a>
							</li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="home">
								<div class="col-md-12 p-0>">
									<div class="table-responsive">
										<table class="table">
											<tr>
												<th>Package</th>
												<th>Per Pills</th>
												<th>Price</th>
												<th>Savings</th>
												<th>Bonus</th>
												<th>order</th>
											</tr>
											<tr>
												<td>500mg x 90pills</td>
												<td>$0.61</td>
												<td>$8.91</td>
												<td></td>
												<td>+Cialis</td>
												<td><a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>
											<tr>
												<td>500mg x 60pills</td>
												<td>$0.56</td>
												<td>$67.78</td>
												<td class="text-orange">$17.83</td>
												<td>+levitra</td>
												<td><a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>
											<tr>
												<td>500mg x 60pills</td>
												<td>$0.56</td>
												<td>$67.78</td>
												<td class="text-orange">$17.83</td>
												<td>+levitra</td>
												<td><a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>
											<tr>
												<td>500mg x 90pills</td>
												<td>$0.61</td>
												<td>$55.26</td>
												<td class="text-orange">$8.91</td>
												<td>+Cialis</td>
												<td><a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>
											<tr>
												<td>500mg x 60pills</td>
												<td>$0.56</td>
												<td>$67.78</td>
												<td class="text-orange">$17.83</td>
												<td>+levitra</td>
												<td><a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>
											<tr>
												<td>500mg x 60pills</td>
												<td>$0.56</td>
												<td>$67.78</td>
												<td class="text-orange">$17.83</td>
												<td>+levitra</td>
												<td><a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></td>
											</tr>
										</table>
									</div>
								</div>
							</div>
							<div role="tabpanel" class="tab-pane" id="tab">
								cacacacac
							</div>
							<div role="tabpanel" class="tab-pane" id="tab1">
								bdbdbdb
							</div>
							<div role="tabpanel" class="tab-pane" id="tab2">
								sdgsdfgdfsg
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12 p-0 clearfix">
					<div class="p-accord-wrap">
						<div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="headingOne">
									<h4 class="panel-title">
										<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Product Description
										</a>
									</h4>
								</div>
								<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
									<div class="panel-body">
										<p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="headingTwo">
									<h4 class="panel-title">
										<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Sefty Information
										</a>
									</h4>
								</div>
								<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
									<div class="panel-body">
										<p> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading" role="tab" id="headingThree">
									<h4 class="panel-title">
										<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
											<i class="more-less glyphicon glyphicon-plus"></i>
											Side Effects
										</a>
									</h4>
								</div>
								<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
									<div class="panel-body">
										<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
									</div>
								</div>
							</div>
						</div><!-- panel-group -->
					</div><!-- container -->
				</div>
				<div class="col-md-12 p-0 clearfix">
					<div class="sbb text-light-green">
						<h3>Related Products</h3>
					</div>
					<div class="col-md-12 p-0">
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include "include/footer.php" ?>
