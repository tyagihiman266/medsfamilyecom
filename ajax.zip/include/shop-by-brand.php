<div class="sbb text-light-green">
							<h3>Search by First Letter</h3>
						</div>
							<div class="all-brand">
							<ul class="clearfix">
								<li class="activ"><a href="">ALL</a></li>
								<li><a href="<?php echo $fulllink ?>?search=a">A</a></li>
								<li><a href="<?php echo $fulllink ?>?search=b">B</a></li>
								<li><a href="<?php echo $fulllink ?>?search=c">C</a></li>
								<li><a href="<?php echo $fulllink ?>?search=d">D</a></li>
								<li><a href="<?php echo $fulllink ?>?search=e">E</a></li>
								<li><a href="<?php echo $fulllink ?>?search=f">F</a></li>
								<li><a href="<?php echo $fulllink ?>?search=g">G</a></li>
								<li><a href="<?php echo $fulllink ?>?search=h">H</a></li>
								<li><a href="<?php echo $fulllink ?>?search=i">I</a></li>
								<li><a href="<?php echo $fulllink ?>?search=j">J</a></li>
								<li><a href="<?php echo $fulllink ?>?search=k">K</a></li>
								<li><a href="<?php echo $fulllink ?>?search=l">L</a></li>
								<li><a href="<?php echo $fulllink ?>?search=m">M</a></li>
								<li><a href="<?php echo $fulllink ?>?search=n">N</a></li>
								<li><a href="<?php echo $fulllink ?>?search=o">O</a></li>
								<li><a href="<?php echo $fulllink ?>?search=p">P</a></li>
								<li><a href="<?php echo $fulllink ?>?search=q">Q</a></li>
								<li><a href="<?php echo $fulllink ?>?search=r">R</a></li>
								<li><a href="<?php echo $fulllink ?>?search=s">S</a></li>
								<li><a href="<?php echo $fulllink ?>?search=t">T</a></li>
								<li><a href="<?php echo $fulllink ?>?search=u">U</a></li>
								<li><a href="<?php echo $fulllink ?>?search=v">V</a></li>
								<li><a href="<?php echo $fulllink ?>?search=w">W</a></li>
								<li><a href="<?php echo $fulllink ?>?search=x">X</a></li>
								<li><a href="<?php echo $fulllink ?>?search=y">Y</a></li>
								<li><a href="<?php echo $fulllink ?>?search=z">Z</a></li>
							</ul>
						</div>