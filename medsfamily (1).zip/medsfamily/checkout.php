<section class="header-top-main">
	<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php";
  if(isset($_SESSION['user_id'])){
		  $uid = $_SESSION['user_id'] ;
	       }else{
		  $uid = session_id() ;
	      }
          $cartcountpackage=$objU->getResult('select * from cart where user_temp_id="'.$uid.'"  ');
$countcart=count($cartcountpackage);

           if($countcart==0) {
           	header('location:signup');

           	}
?>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row checkout-main">
			<div class="col-md-12 login-padding regis-sec checkout-top">
				<div role="tabpanel" class="f-tab">
					<!-- Nav tabs -->
					<ul class="nav nav-tabs checkout-t" role="tablist">
						<li role="presentation" class="active">
							<a href="#home" aria-controls="home" role="tab" data-toggle="tab">Shipping</a>
							<span>1</span>
						</li>
						<li role="presentation">
							<a href="#tab" aria-controls="tab" role="tab" data-toggle="tab">Review & Payments</a>
							<span>2</span>
						</li>
					</ul>
					<!-- Tab panes -->
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane active" id="home">
							<div class="login-warp clearfix">
								<div class="col-md-7 login-sec pl-0">
									<div class="sbb text-light-green">
										<h3>shipping details</h3>
									</div>
									<form action="" id="frmcheckout" method="POST" role="form" class="custom-form">
										<div class="form-group">
											<label for="">Email Address <span class="color-red">*</span></label>
											<input type="email" class="form-control" name="billing_email" id="" placeholder="" required>
										</div>
										<div class="form-group">
											<label for="">First Name <span class="color-red">*</span></label>
											<input type="text" class="form-control" id="" name="billing_fname" placeholder="" required>
										</div>
										<div class="form-group">
											<label for="">Last Name <span class="color-red">*</span></label>
											<input type="text" class="form-control" id="" name="billing_lname" placeholder="" required>
										</div>
										<!--<div class="form-group">
											<label for="">Company <span class="color-red">*</span></label>
											<input type="text" class="form-control" id="" name="billing_lname" placeholder="" required>
										</div> -->
										<div class="form-group">
											<label for="">Street Address <span class="color-red">*</span></label>
											<input type="text" name="billing_address1" class="form-control" id="" placeholder="" required>
											<p></p>
											<input type="text" name="billing_address2"  class="form-control" id="" placeholder="" required>
										</div>
										<div class="form-group">
											<label for="">country <span class="color-red">*</span></label>
											  <select name="billing_country" class="form-control" id="country">
                                          <?php   
                                            $query = "Select * from countries";
                                            $queryCn = $objU->getResult($query);
                                              foreach ($queryCn as $value) {
                                            ?>  
                                            <option value="<?php echo $value['id']; ?>" ><? echo $value['country']; ;?></option>              
                                            <?php }
                                          ?>                                   
                                   </select>
										</div>
										<div class="form-group custom-select">
											<label for="">State/proviance<span class="color-red">*</span></label>
											 <select name="billing_state" class="form-control" id="state">
                                      <option value="">Select State</option>                                       
                                   </select>
											<i class="fa fa-angle-down" aria-hidden="true"></i>
										</div>

											<div class="form-group custom-select">
											<label for="">City<span class="color-red">*</span></label>
											 <select name="billing_city" class="form-control" id="city">
                                      <option value="">Select City</option>                                       
                                   </select>
											<i class="fa fa-angle-down" aria-hidden="true"></i>
										</div>
										<div class="form-group">
											<label for="">Zip/Postal Code <span class="color-red">*</span></label>
											<input type="text" name="billing_zip" class="form-control" id="" placeholder="" required>
										</div>
									
										<div class="form-group">
											<label for="">Phone Number <span class="color-red">*</span></label>
											<input type="text" name="billing_mobile" class="form-control" id="" placeholder="" required>
										</div>
									

                                    <!--
									<div class="col-md-12 p-0">
										<div class="sbb text-light-green">
											<h3>shipping Medhod</h3>
										</div>
										<div class="table-responsive">
											<table class="table">
												<tr>
													<th class="border-none">Select Method</th>
													<th class="border-none">Price</th>
													<th class="border-none">Method Title</th>
													<th class="border-none">Career Title</th>
												</tr>
												<tr>
													<td class="border-none">
														<div class="form-group">
															<input type="radio" name="selet-one">
														</div>
													</td>
													<td class="border-none">$5.00</td>
													<td class="border-none">Fixed</td>
													<td class="border-none">Flat Rate</td>
												</tr>
											</table>
										</div>
									</div>

									 -->
									<div class="col-md-12 p-0">
										<div class="sbb text-light-green">
											<h3>Acknowledgements</h3>
										</div>
										<div class="table-responsive">
											<table class="table">
												<tr>
													<td class="custom-check border-none">
														<ul>
															<li>
																<div class="checkbox new-check">
																	<input id="checkbox9" name="acknowledge" type="checkbox">
																	<label for="checkbox9"> </label>
																</div>
															</li>
														</ul>
													</td>
													<td class="border-none">
														<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here,</p>
													</td>
												</tr>
											</table>
										</div>
									</div>

								</form>
									<div class="col-md-12 p-0">
										<div class="col-md-3">
								<a href="#myModal" class="create-account" data-toggle="modal" data-target="#myModal">Contineu</a>
										</div>
										<div class="col-md-3">
											<!--<a href="#" class="create-account">Contineu</a>-->
										</div>
										<div class="col-md-6">
										</div>
									</div>
								</div>
								<div class="col-md-5 create-acc-sec">
									<div class="table-responsive summery-wrap">
										<table class="table">
											<tr>
												<td colspan="3" class="border-none summ"><b>Order Summery</b></td>
											</tr>
											<tr>
												<td colspan="3" class="border-none"><?php echo $countcart; ?> Item In Cart</td>
											</tr>


                                          <?php 
                                        

                                       $subtotal = '';
                                          foreach($cartcountpackage as $keycheckout => $keycheckouval) {

                                          	 $packagedetail=$objU->getResult("SELECT * FROM `tbl_product_package` join tbl_product on tbl_product.id=tbl_product_package.product_id join product_varient on product_varient.id=tbl_product_package.varient_id join tbl_company on tbl_company.id=tbl_product_package.company_id where tbl_product_package.id='".$keycheckouval['package_id']."'");


                                              $subtotal += $keycheckouval['quantity']*$packagedetail[0]['price'];

                                          	?>
                                          
											<tr>
												<td width="10%"><img src="images/product.jpg" height="50" width="30"></td>
												<td>
													<p><?php echo $packagedetail['name']; ?></p>
													<font>Qty:<?php echo $keycheckouval['quantity']; ?></font>
												</td>
												<td><?php echo $_SESSION['currency_symbol']; ?><?php echo $packagedetail[0]['price']; ?></td>
											</tr>
                                           <?php } ?>

										
											<tr>
												<td colspan="3"></td>
											</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="tab">
							
							
							
							
							
							
							
							
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include "include/footer.php" ?>
<!-- Local bootstrap CSS & JS -->
<!-- Local bootstrap CSS & JS -->

	<div id="myModal" class="modal fade in new-model">
        <div class="modal-dialog">
            <div class="modal-content">
 
                <div class="modal-header">
                    <a class="btn pull-right" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
                   
                </div>
                <div class="modal-body clearfix">
                 <div class="col-md-12 buton-m load-m-o-r-e text-center" id="addprecpcont">
				<a href="javascript:void(0)" id="addprecp">+ Add Prescription</a>
			</div> 

			
				  <div class="col-md-12 buton-m load-m-o-r-e text-center" id="showprecp" style="display:none;">
				<input type="file" name="Prescription_file" id="Prescription_file">
			</div> 

			
			<div class="col-md-12 button-m load-m-o-r-e text-center">
				<a href="javascript:void(0)">Send Later</a>
			</div>
                  
                </div>
                <div class="modal-footer">
                  
                </div>
 
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dalog -->
    </div><!-- /.modal -->






<script>
    var $tabs = $('.checkout-t li');
    $('.create-account').on('click', function() {
        $tabs.filter('.active').next('li').find('a[data-toggle="tab"]').tab('show');
        $tabs.filter('.active').prev('li').addClass('active-warning');
    }); 
    $('.contineu-s').on('click', function() {
        $tabs.filter('.active').prev('li').find('a[data-toggle="tab"]').tab('show');
        $tabs.filter('.active').next('li').addClass('active-warning');
    });

     $(document).on('change','#country',function(){

      var country=$('#country').val();
     $.ajax({
            type: "post",
            url: "ajax/getstate.php",
            data: {"country_id":country},
            success: function(result){
             $("#state").html(result);
           
        }});


    });

      $(document).on('change','#state',function(){

      var state=$('#state').val();
     $.ajax({
            type: "post",
            url: "ajax/getcity.php",
            data: {"state_id":state},
            success: function(result){
             $("#city").html(result);
           
        }});


    });


      $(document).on('click','#addprecp',function(){

         $('#showprecp').show();
          $('#addprecpcont').hide();
});
</script>