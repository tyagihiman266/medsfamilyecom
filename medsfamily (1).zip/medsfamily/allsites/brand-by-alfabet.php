<section class="header-top-main">
	<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php"
?>
</section>
<section class="clearfix bearcrumb-back">
	<div class="container">
		<div class="row">
			<div class="beardcrumb">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="">Search Result By Brand</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-12 shop-by-alp">
				<div class="sbb text-light-green">
					<h3>Shop By Alphabet</h3>
				</div>
				<div class="all-brand">
					<ul class="clearfix">
						<li class="activ"><a href="">ALL</a></li>
						<li><a href="">A</a></li>
						<li><a href="">B</a></li>
						<li><a href="">C</a></li>
						<li><a href="">D</a></li>
						<li><a href="">E</a></li>
						<li><a href="">F</a></li>
						<li><a href="">G</a></li>
						<li><a href="">H</a></li>
						<li><a href="">I</a></li>
						<li><a href="">J</a></li>
						<li><a href="">M</a></li>
						<li><a href="">L</a></li>
						<li><a href="">M</a></li>
						<li><a href="">N</a></li>
						<li><a href="">O</a></li>
						<li><a href="">P</a></li>
						<li><a href="">Q</a></li>
						<li><a href="">R</a></li>
						<li><a href="">S</a></li>
						<li><a href="">T</a></li>
						<li><a href="">U</a></li>
						<li><a href="">V</a></li>
						<li><a href="">W</a></li>
						<li><a href="">X</a></li>
						<li><a href="">Y</a></li>
						<li><a href="">Z</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-12">
				<div class="alphabet-top">
					<h2>A</h2>
				</div>
				<div class="alphabets-main">
					<ul>
						<li><a href="javascript:void(0)">Abelcet</a></li>
						<li><a href="javascript:void(0)">Abilify</a></li>
						<li><a href="javascript:void(0)">Abilify Maintena injection</a></li>
						<li><a href="javascript:void(0)">Acanya</a></li>
						<li><a href="javascript:void(0)">Accupril</a></li>
						<li><a href="javascript:void(0)">Accuretic</a></li>
						<li><a href="javascript:void(0)">Actemra</a></li>
						<li><a href="javascript:void(0)">Actimmune</a></li>
						<li><a href="javascript:void(0)">Activase</a></li>
						<li><a href="javascript:void(0)">Adagen</a></li>
						<li><a href="javascript:void(0)">Adcetris</a></li>
						<li><a href="javascript:void(0)">Adcirca tablets</a></li>
						<li><a href="javascript:void(0)">Adempas Tablet</a></li>
						<li><a href="javascript:void(0)">Adlyxin</a></li>
						<li><a href="javascript:void(0)">Advair diskus 100/50</a></li>
						<li><a href="javascript:void(0)">Advair diskus 250/50</a></li>
						<li><a href="javascript:void(0)">Advair diskus 500/50</a></li>
						<li><a href="javascript:void(0)">Advair HFA</a></li>
						<li><a href="javascript:void(0)">Abelcet</a></li>
						<li><a href="javascript:void(0)">Abilify</a></li>
						<li><a href="javascript:void(0)">Abilify Maintena injection</a></li>
						<li><a href="javascript:void(0)">Acanya</a></li>
						<li><a href="javascript:void(0)">Accupril</a></li>
						<li><a href="javascript:void(0)">Accuretic</a></li>
						<li><a href="javascript:void(0)">Actemra</a></li>
						<li><a href="javascript:void(0)">Actimmune</a></li>
						<li><a href="javascript:void(0)">Activase</a></li>
						<li><a href="javascript:void(0)">Adagen</a></li>
						<li><a href="javascript:void(0)">Adcetris</a></li>
						<li><a href="javascript:void(0)">Activase</a></li>
						<li><a href="javascript:void(0)">Adagen</a></li>
						<li><a href="javascript:void(0)">Adcetris</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-12">
				<div class="alphabet-top">
					<h2>b</h2>
				</div>
				<div class="alphabets-main">
					<ul>
						<li><a href="javascript:void(0)"> Bacitracin</a></li>
						<li><a href="javascript:void(0)">Banzel</a></li>
						<li><a href="javascript:void(0)">Baraclude Oral Solution</a></li>
						<li><a href="javascript:void(0)">Baraclude tablets</a></li>
						<li><a href="javascript:void(0)">Basaglar</a></li>
						<li><a href="javascript:void(0)">Baxdela</a></li>
						<li><a href="javascript:void(0)">Bebulin</a></li>
						<li><a href="javascript:void(0)">Beconase AQ (nasal spray)</a></li>
						<li><a href="javascript:void(0)">Beleodaq Powder</a></li>
						<li><a href="javascript:void(0)">Belsomra</a></li>
						<li><a href="javascript:void(0)"> Bacitracin</a></li>
						<li><a href="javascript:void(0)">Banzel</a></li>
						<li><a href="javascript:void(0)">Baraclude Oral Solution</a></li>
						<li><a href="javascript:void(0)">Baraclude tablets</a></li>
						<li><a href="javascript:void(0)">Basaglar</a></li>
						<li><a href="javascript:void(0)">Baxdela</a></li>
						<li><a href="javascript:void(0)">Bebulin</a></li>
						<li><a href="javascript:void(0)">Beconase AQ (nasal spray)</a></li>
						<li><a href="javascript:void(0)">Beleodaq Powder</a></li>
						<li><a href="javascript:void(0)">Belsomra</a></li>
						<li><a href="javascript:void(0)"> Bacitracin</a></li>
						<li><a href="javascript:void(0)">Banzel</a></li>
						<li><a href="javascript:void(0)">Baraclude Oral Solution</a></li>
						<li><a href="javascript:void(0)">Baraclude tablets</a></li>
						<li><a href="javascript:void(0)">Basaglar</a></li>
						<li><a href="javascript:void(0)">Baxdela</a></li>
						<li><a href="javascript:void(0)">Bebulin</a></li>
						<li><a href="javascript:void(0)">Beconase AQ (nasal spray)</a></li>
						<li><a href="javascript:void(0)">Beleodaq Powder</a></li>
						<li><a href="javascript:void(0)">Belsomra</a></li>
						<li><a href="javascript:void(0)"> Bacitracin</a></li>
						<li><a href="javascript:void(0)">Banzel</a></li>
						<li><a href="javascript:void(0)">Baraclude Oral Solution</a></li>
						<li><a href="javascript:void(0)">Baraclude tablets</a></li>
						<li><a href="javascript:void(0)">Basaglar</a></li>
						<li><a href="javascript:void(0)">Baxdela</a></li>
						<li><a href="javascript:void(0)">Bebulin</a></li>
						<li><a href="javascript:void(0)">Beconase AQ (nasal spray)</a></li>
						<li><a href="javascript:void(0)">Beleodaq Powder</a></li>
						<li><a href="javascript:void(0)">Belsomra</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-12">
				<div class="alphabet-top">
					<h2>c</h2>
				</div>
				<div class="alphabets-main">
					<ul>
						<li><a href="javascript:void(0)">Cabometyx</a></li>
						<li><a href="javascript:void(0)">Caduet</a></li>
						<li><a href="javascript:void(0)">Calan</a></li>
						<li><a href="javascript:void(0)">Calquence</a></li>
						<li><a href="javascript:void(0)">Campath 30mg</a></li>
						<li><a href="javascript:void(0)">Camptosar</a></li>
						<li><a href="javascript:void(0)">Canasa</a></li>
						<li><a href="javascript:void(0)">Cancidas</a></li>
						<li><a href="javascript:void(0)">Caprelsa</a></li>
						<li><a href="javascript:void(0)">Carac Cream</a></li>
						<li><a href="javascript:void(0)">Carbaglu</a></li>
						<li><a href="javascript:void(0)">Carbatrol</a></li>
						<li><a href="javascript:void(0)">Cardura</a></li>
						<li><a href="javascript:void(0)">Carimune NF</a></li>
						<li><a href="javascript:void(0)">Carnitor</a></li>
						<li><a href="javascript:void(0)">Cathflo</a></li>
						<li><a href="javascript:void(0)">Caverject</a></li>
						<li><a href="javascript:void(0)">Celebrex</a></li>
						<li><a href="javascript:void(0)">CellCept</a></li>
						<li><a href="javascript:void(0)">Cabometyx</a></li>
						<li><a href="javascript:void(0)">Caduet</a></li>
						<li><a href="javascript:void(0)">Calan</a></li>
						<li><a href="javascript:void(0)">Calquence</a></li>
						<li><a href="javascript:void(0)">Campath 30mg</a></li>
						<li><a href="javascript:void(0)">Camptosar</a></li>
						<li><a href="javascript:void(0)">Canasa</a></li>
						<li><a href="javascript:void(0)">Cancidas</a></li>
						<li><a href="javascript:void(0)">Caprelsa</a></li>
						<li><a href="javascript:void(0)">Carac Cream</a></li>
						<li><a href="javascript:void(0)">Carbaglu</a></li>
						<li><a href="javascript:void(0)">Carbatrol</a></li>
						<li><a href="javascript:void(0)">Cardura</a></li>
						<li><a href="javascript:void(0)">Carimune NF</a></li>
						<li><a href="javascript:void(0)">Carnitor</a></li>
						<li><a href="javascript:void(0)">Cathflo</a></li>
						<li><a href="javascript:void(0)">Caverject</a></li>
						<li><a href="javascript:void(0)">Celebrex</a></li>
						<li><a href="javascript:void(0)">CellCept</a></li>
						<li><a href="javascript:void(0)">Cabometyx</a></li>
						<li><a href="javascript:void(0)">Caduet</a></li>
						<li><a href="javascript:void(0)">Calan</a></li>
						<li><a href="javascript:void(0)">Calquence</a></li>
						<li><a href="javascript:void(0)">Campath 30mg</a></li>
						<li><a href="javascript:void(0)">Camptosar</a></li>
						<li><a href="javascript:void(0)">Canasa</a></li>
						<li><a href="javascript:void(0)">Cancidas</a></li>
						<li><a href="javascript:void(0)">Caprelsa</a></li>
						<li><a href="javascript:void(0)">Carac Cream</a></li>
						<li><a href="javascript:void(0)">Carbaglu</a></li>
						<li><a href="javascript:void(0)">Carbatrol</a></li>
						<li><a href="javascript:void(0)">Cardura</a></li>
						<li><a href="javascript:void(0)">Carimune NF</a></li>
						<li><a href="javascript:void(0)">Carnitor</a></li>
						<li><a href="javascript:void(0)">Cathflo</a></li>
						<li><a href="javascript:void(0)">Caverject</a></li>
						<li><a href="javascript:void(0)">Celebrex</a></li>
						<li><a href="javascript:void(0)">CellCept</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-12">
				<div class="alphabet-top">
					<h2>d</h2>
				</div>
				<div class="alphabets-main">
					<ul>
						<li><a href="javascript:void(0)">Daklinza</a></li>
						<li><a href="javascript:void(0)">Daliresp</a></li>
						<li><a href="javascript:void(0)">Dalvance Vials</a></li>
						<li><a href="javascript:void(0)">Daraprim tablet</a></li>
						<li><a href="javascript:void(0)">Darzalex</a></li>
						<li><a href="javascript:void(0)">Daypro</a></li>
						<li><a href="javascript:void(0)">Defitelio</a></li>
						<li><a href="javascript:void(0)">Delzicol DR Capsules</a></li>
						<li><a href="javascript:void(0)">Demser capsules</a></li>
						<li><a href="javascript:void(0)">Depakote</a></li>
						<li><a href="javascript:void(0)">Daklinza</a></li>
						<li><a href="javascript:void(0)">Daliresp</a></li>
						<li><a href="javascript:void(0)">Dalvance Vials</a></li>
						<li><a href="javascript:void(0)">Daraprim tablet</a></li>
						<li><a href="javascript:void(0)">Darzalex</a></li>
						<li><a href="javascript:void(0)">Daypro</a></li>
						<li><a href="javascript:void(0)">Defitelio</a></li>
						<li><a href="javascript:void(0)">Delzicol DR Capsules</a></li>
						<li><a href="javascript:void(0)">Demser capsules</a></li>
						<li><a href="javascript:void(0)">Depakote</a></li>
						<li><a href="javascript:void(0)">Daklinza</a></li>
						<li><a href="javascript:void(0)">Daliresp</a></li>
						<li><a href="javascript:void(0)">Dalvance Vials</a></li>
						<li><a href="javascript:void(0)">Daraprim tablet</a></li>
						<li><a href="javascript:void(0)">Darzalex</a></li>
						<li><a href="javascript:void(0)">Daypro</a></li>
						<li><a href="javascript:void(0)">Defitelio</a></li>
						<li><a href="javascript:void(0)">Delzicol DR Capsules</a></li>
						<li><a href="javascript:void(0)">Demser capsules</a></li>
						<li><a href="javascript:void(0)">Depakote</a></li>
						<li><a href="javascript:void(0)">Daklinza</a></li>
						<li><a href="javascript:void(0)">Daliresp</a></li>
						<li><a href="javascript:void(0)">Dalvance Vials</a></li>
						<li><a href="javascript:void(0)">Daraprim tablet</a></li>
						<li><a href="javascript:void(0)">Darzalex</a></li>
						<li><a href="javascript:void(0)">Daypro</a></li>
						<li><a href="javascript:void(0)">Defitelio</a></li>
						<li><a href="javascript:void(0)">Delzicol DR Capsules</a></li>
						<li><a href="javascript:void(0)">Demser capsules</a></li>
						<li><a href="javascript:void(0)">Depakote</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-12 mt-60 load-m-o-r-e text-center">
				<a href="javascript:void(0)">Load More</a>
			</div>
		</div>
	</div>
</section>
<?php include "include/footer.php" ?>
