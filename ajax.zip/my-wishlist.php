<section class="header-top-main">
	<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php"
?>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<section class="my-account">
				<div class="container">
					<div class="row">

						<div class="col-md-12" style="border-bottom: 1px solid #ccc;
    margin-bottom: 20px;">
							<h3>My Account</h3>

						</div>

<?php include('accout-leftsidebar.php'); ?>
						<div class="col-md-10 my-account-right">
							<div class="col-md-12 pr-0">

  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#wishlist">My Wishlist</a></li>
  </ul>

  <div class="tab-content col-md-12">
    <div id="wishlist" class="tab-pane fade in active">
      <div class="col-md-12 p-0 wishlist text-center">


      
   
       <div class="col-md-3 p-7">
    <div class="iteam-wrap">
                            <div class="item"> <img src="images/cart-img1.png" class="img-responsive border">
                              
                                <div class="wishlist-product">
                                    <a href=""><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>
                                </div>
                                <div class="mar-tb">
                                <a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></div>
                            </div>
                                <p class="m-0 pt-1">TAG Heuer Connected </p>
                          
                        </div>
    
      </div>
      <div class="col-md-3 p-7">
    <div class="iteam-wrap">
                            <div class="item"> <img src="images/cart-img1.png" class="img-responsive border">
                              
                                <div class="wishlist-product">
                                    <a href=""><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>
                                </div> <div class="mar-tb">
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></div>
                            </div>
                                <p class="m-0 pt-1">TAG Heuer Connected</p>
                          
                        </div>
    
      </div>
     <div class="col-md-3 p-7">
    <div class="iteam-wrap">
                            <div class="item"> <img src="images/cart-img1.png" class="img-responsive border">
                              
                                <div class="wishlist-product">
                                    <a href=""><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>
                                </div>
                                 <div class="mar-tb">
									 <a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a></div>
                            </div>
                                <p class="m-0 pt-1">TAG Heuer Connected</p>
                          
                        </div>
    
      </div> 
  
      </div>
    </div>
    
    
    
  </div>

           </div>
						</div>
					</div>
				</div>
			</section>


		</div>
	</div>
</section>
<?php include "include/footer.php" ?>
