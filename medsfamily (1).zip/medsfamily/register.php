<section class="header-top-main">
<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php";

      if($_REQUEST['submitsignup']=='yes') 
                     {

                       
                        $fname = $_POST['firstname'];
                        $lname = $_POST['lastname'];
                        $name= $fname.' '.$lname;
                        $email = $_POST['email'];   
                // $password = $_POST['password'];
                $password = base64_encode($_POST['password']);
                // $result = mysql_query("SELECT * FROM user_data where email ='".$email."'");
                // $num_rows = mysql_num_rows($result);

                $query = "SELECT * FROM user_data where email ='".$email."' ";
                $result = $objU->getResult($query);
                $num_rows = count($result);

                if($num_rows > 0){
                   $_SESSION['sess_msg_signup']='You are already registerd please login';  
                    }

                    else{
                        
                    $colArray = array('password'=>$password,'name'=>$name,'email'=>$email,'fname'=>$fname,'lname'=>$lname,'status'=>1);
                    $resultU = $objU->insertQuery($colArray,'user_data');
                    $last_id = $resultU;

                    if ($resultU!=true) {
                        die();
                    }

                    



                      $_SESSION['fname'] = $fname;
                    $_SESSION['lname'] = $lname;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_id'] = $last_id;

                    //$resultU = mysql_query($sqlU);
                                    
                                $str = base64_encode($email);

                                $email_message = "\n Welcome to Medsfamily.";
                        $email_subject = 'Medsfamily';

                        $email_from = 'info@medsfamily.com';

                        $email_to = $email;

                    
                        $headers = 'From: '.$email_from."\r\n".

                        'MIME-Version: 1.0' . "\r\n".

                        'Content-type: text/html; charset=iso-8859-1' . "\r\n".

                        'Reply-To: '.$email_from."\r\n" .

                        'X-Mailer: PHP/' . phpversion();

                     $mail= @mail($email_to, $email_subject, $email_message, $headers); 

                     if ($mail == TRUE) {                

               
                      
                    echo "<META http-equiv='refresh' content='0;URL=index.php'>";

                   // header('Location:index.php');

                   

                     } else {

                    $_SESSION['msg'] = '
                        <script>
                            alert("You are not Ragistered");
                        </script>';

                    // header('Location:index.php');

                   echo "<META http-equiv='refresh' content='0;URL=index.php'> </h4>";

                 // header('Location:register.php?status=fail');

                  

                    }

        

                    }


                      }




?>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-12 login-padding regis-sec">
				<h3 class="login-sec-top">Create New Customer Account</h3>
				<div class="login-warp clearfix">
					<div class="col-md-6 login-sec">
						<h3>Personal Information</h3>
						<form action="" method="POST" role="form" class="custom-form">
							<input type="hidden" name="submitsignup" value="yes">
							<div class="form-group">
								<label for="">First Name <span class="color-red">*</span></label>
							<input type="text" name="firstname" class="form-control" id="fname" placeholder="" required>
							</div>
							<div class="form-group">
								<label for="">Last Name <span class="color-red">*</span></label>
								<input type="text" name="lastname" class="form-control" id="lname" placeholder="" required>
							</div>
					
						
					</div>
					<div class="col-md-6 create-acc-sec">
						<h3>Sign- in Information</h3>
					<form action="" method="POST" id="signupform" role="form" class="custom-form">
							<div class="form-group">
								<label for="">Email <span class="color-red">*</span></label>
								<input type="text" name="email" class="form-control" id="email" placeholder="" required>
							</div>
							<div class="form-group">
								<label for="">Password <span class="color-red">*</span></label>
								<input type="password" name="password" class="form-control" id="pass" placeholder="" required>
							</div>
							<div class="form-group">
								<label for="">Confirm Password <span class="color-red">*</span></label>
								<input type="password" name="password_confirm" class="form-control" id="confirm_pass" placeholder="" required>
							</div>
						
					
						
					</div>
					<div class="col-md-12 create-m-b">
						<button class="create-account" type="submit" name="submit">Create an account</button>
					
					</div>
					
				</div>
			</div>
		</div>
	</div>
</section>

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.min.js"></script>
<script>
$("#signupform").validate({
    rules:{
      firstName: 'required',
      lastName: 'required',
      email:{
        required: true,
        email: true
      },
      password:{
        required: true,
        minlength: 6
      },
      password_confirm : {
                    minlength : 6,
                    equalTo : "#pass"
                }
    },
    messages: {
      firstName: 'This field is required',
      lastName: 'This field is required',       
      email: {
        equired: "Please enter email",
        email: "Please enter email type"
      },
      password: {
        required: "Please enter Current Password",
        minlength: "Please enter atleast 6 Charecter"
      },
      password_confirm:'Password and confirm password should same.'
    }

  });
</script>












































<?php include "include/footer.php" ?>