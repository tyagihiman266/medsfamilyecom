<section class="header-top-main">
	<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php"
?>
</section>
<section class="clearfix bearcrumb-back">
	<div class="container">
		<div class="row">
			<div class="beardcrumb">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="">Search Result</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-12 Search-result-top ">
				<h3 class="login-sec-top">Search Result For: 'Immunity'</h3>
				<div class="col-md-12 p-0">
					<div class="col-md-6">
						<p>16 Iteams</p>
					</div>
					<div class="col-md-6">
					<div class="col-md-8"><p class="pull-right" style="margin-top:10px;">Sort By</p></div><div class="col-md-4">	<div class="search-f-wrap custom-select pull-right">
							
							<select class="form-control">
								<option>Relevance</option>
								<option>Relevance</option>
								<option>Relevance</option>
								<option>Relevance</option>
							</select>
							<i class="fa fa-angle-down" aria-hidden="true"></i>
						</div>
						</div>
						
					</div>
					
				</div>
			<div class="col-md-12">
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f1.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
						<div class="col-md-3 p-0-7">
							<div class="feature-wrap">
								<img src="images/f2.jpg" class="img-responsive">
								<div class="feature-cost text-center">
									<p>Anti Sunspot</p>
									<span>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
										<i class="fa fa-star" aria-hidden="true"></i>
									</span>
									<h3>$24.00</h3>
									<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
								</div>
							</div>
						</div>
					</div>
				
				
				
				
				
				
				
				
				
				
				
			</div>
		</div>
	</div>
</section>
<?php include "include/footer.php" ?>
