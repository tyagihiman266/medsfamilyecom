<div class="col-md-2 my-account-left">
							<ul>
								<li class="active"><a href="my-account"><i class="fa fa-user-o"></i> Account Details</a></li>

								<li><a href="my-order"><i class="fa fa-list-ul"></i> My Order</a></li>
								<li><a href="my-wishlist"><i class="fa fa-heart-o"></i> Wishlist</a></li>

							</ul>
						</div>