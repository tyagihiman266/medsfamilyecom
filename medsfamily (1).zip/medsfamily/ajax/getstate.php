<?php
@session_start();
include '../controls/Users.php';
include '../medsfamily_function.php' ;
$objU = new User();

   
if($_REQUEST['country_id'])
                {
                

                $query = "SELECT * FROM state where country_id ='".$_REQUEST['country_id']."' ";
                $result = $objU->getResult($query);
                $num_rows = count($result);

              if($num_rows >0){ 
                 echo "<option value=''>Select State</option>";
                foreach($result as $key => $val){
                echo "<option value='".$val['state_id']."'>".$val['state']."</option>";

                }  }else {
                     echo "<option value=''>Select State</option>";
                }




              }

              

