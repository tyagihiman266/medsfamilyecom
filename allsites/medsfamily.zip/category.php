<?php 
$pagetitle="pharmacy";
$keyword="All medicin available";
$description="pharmacy Website";
include "include/header.php"
?>
<section class="clearfix bearcrumb-back">
	<div class="container">
		<div class="row">
			<div class="beardcrumb">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="">Category</a></li>

				</ul>
			</div>
		</div>
	</div>
</section>
<section class="clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-9">
				<div class="col-md-12 p-0">
					<div class="category-banner">
						<img src="images/category-banner.jpg" class="img-responsive">
						<p>simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance.</p>
					</div>
				</div>
				<div class="col-md-12 p-0">
					<?php include "include/shop-by-brand.php" ?>
				</div>
				<div class="col-md-12 category-main p-0">
					<div class="col-md-3 p-0-7">
						<a href="products.php"><div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div></a>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f1.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>

					<div class="col-md-3 p-0-7">
						<div class="feature-wrap">
							<img src="images/f2.jpg" class="img-responsive">
							<div class="feature-cost text-center">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
								<a href="" class="tab-add-to-cart"><img src="images/shopping-cart.png"> Add to Cart</a>
							</div>
						</div>
					</div>





				</div>
			</div>
		</div>
	</div>
</section>










<?php include "include/footer.php" ?>
