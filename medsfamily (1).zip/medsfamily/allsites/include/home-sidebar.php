<div style="float:left;" class="accordian-left">
				<div class="float-panel" style="width:267px;font-size:13px;background:#ffffff;">
					<div id="accordion">
						<div class="accordian-heading">
							<h3>Category</h3>
						</div>
						<ul>
							<li>
								<div><a href="category.php">Special offer</a></div>
								<ul>
									<li><a href="category.php">Lorem ipsum</a></li>
									<li><a href="category.php">Dolor sit</a></li>
								</ul>
							</li>
							<li>
								<div><a href="category.php">Best Seller</a></div>
								<ul>
									<li><a href="category.php">Finibus Bonorum</a></li>
									<li><a href="category.php">Sed ut</a></li>
									<li><a href="category.php">Neque porro</a></li>
									<!--<li>
										<div>Commodo Rhoncus</div>
										<ul>
											<li><a href="demo.html">Current</a></li>
											<li><a href="?132">Consectetur</a></li>
										</ul>
									</li>-->
								</ul>
							</li>
							<li>
								<div><a href="category.php">Allergies</a></div>
								<ul>
									<li><a href="category.php">Minima veniam</a></li>
									<li><a href="category.php">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
							<li>
								<div>Allergies</div>
								<ul>
									<li><a href="?31">Minima veniam</a></li>
									<li><a href="?32">Voluptate velit</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
				<div class="left-banner">
					<img src="images/lf-banner.jpg" class="img-responsive">
					<img src="images/lf-banner1.jpg" class="img-responsive">
				</div>
				<div class="recent-view clearfix">
					<h4>Recent View</h4>
					<ul class="clearfix">
						<li>
							<img src="images/lrv1.jpg" class="img-responsive">
						</li>
						<li>
							<div class="feature-cost">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
							</div>
						</li>
					</ul>
					<ul class="clearfix">
						<li>
							<img src="images/lrv.jpg" class="img-responsive">
						</li>
						<li>
							<div class="feature-cost">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
							</div>
						</li>
					</ul>
					<ul class="clearfix">
						<li>
							<img src="images/lrv1.jpg" class="img-responsive">
						</li>
						<li>
							<div class="feature-cost">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
							</div>
						</li>
					</ul>
					<ul class="clearfix">
						<li>
							<img src="images/lrv.jpg" class="img-responsive">
						</li>
						<li>
							<div class="feature-cost">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
							</div>
						</li>
					</ul>
					<ul class="clearfix">
						<li>
							<img src="images/lrv1.jpg" class="img-responsive">
						</li>
						<li>
							<div class="feature-cost">
								<p>Anti Sunspot</p>
								<span>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
									<i class="fa fa-star" aria-hidden="true"></i>
								</span>
								<h3>$24.00</h3>
							</div>
						</li>
					</ul>
				</div>
			</div>